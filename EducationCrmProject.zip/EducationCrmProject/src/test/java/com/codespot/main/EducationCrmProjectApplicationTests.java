package com.codespot.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationCrmProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
