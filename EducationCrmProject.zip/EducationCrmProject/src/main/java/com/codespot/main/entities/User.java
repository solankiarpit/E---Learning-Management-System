package com.codespot.main.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;

@Entity
public class User{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@Column(nullable = false)
@Pattern(regexp = "^[A-Za-z ]{2,25}$", message = "Name must be 2-25 letters")
private String name;

@Column(nullable = false, unique = true)
@Email(message = "Invalid email format")
private String email;

@Column(nullable = false)
@Pattern(
    regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,25}$",
    message = "Password must be like Ravi@800"
)
private String password;

@Column(nullable = false)
@Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
private String phoneno;

@Column(nullable = false)
@Pattern(regexp = "^[A-Za-z ]{2,25}$", message = "City must be 2-25 letters")
private String city;

@Column(nullable = false)
private Boolean banStatus = false;

// Getters and setters
public Long getId() { return id; }
public void setId(Long id) { this.id = id; }

public String getName() { return name; }
public void setName(String name) { this.name = name; }

public String getEmail() { return email; }
public void setEmail(String email) { this.email = email; }

public String getPassword() { return password; }
public void setPassword(String password) { this.password = password; }

public String getPhoneno() { return phoneno; }
public void setPhoneno(String phoneno) { this.phoneno = phoneno; }

public String getCity() { return city; }
public void setCity(String city) { this.city = city; }

	public boolean isBanStatus() {
	    return banStatus != null && banStatus;
	}
	public void setBanStatus(boolean banStatus) {
		this.banStatus = banStatus;
	}
}
