package com.codespot.main.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codespot.main.entities.User;

public interface CustomerRepository extends JpaRepository<User, Long> 
{
	User findByEmail(String email);
}
